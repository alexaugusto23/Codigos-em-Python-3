class Contato():

	def __init__(self, nome, email, telefone, id_contato=None):
		self.id_contato = id_contato
		self.nome = nome
		self.email = email
		self.telefone = telefone
